package com.vf.hyperbar;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.ConsumerIrManager;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
  ConsumerIrManager ir;
  SharedPreferences prefs;
  LinearLayout root;
  TextView status;
  EditText addressInput, commandInput;
  String[] names={"POWER","MUTE","VOL+","VOL-","PLAY/PAUSE","PREV","NEXT","TRE+","TRE-","BASS+","BASS-","BT","AUX","USB","OPT","COX","FM","TUNING-","FM SCAN","TUNING+","EQ"};
  int selected=0;
  int address=0;
  int command=0;
  @Override public void onCreate(Bundle b){super.onCreate(b);
    ir=(ConsumerIrManager)getSystemService(Context.CONSUMER_IR_SERVICE);
    prefs=getSharedPreferences("codes",MODE_PRIVATE);
    ScrollView scroll=new ScrollView(this); root=new LinearLayout(this);root.setOrientation(1);root.setPadding(24,28,24,30);root.setBackgroundColor(Color.rgb(15,21,31));scroll.addView(root);setContentView(scroll);
    title("VF HYPERBAR 300 BTU"); status=label("IR: "+(ir!=null && ir.hasIrEmitter()?"Pemancar dikesan":"Pemancar tidak dikesan"));
    label("REMOTE — Kod yang belum disimpan tidak akan dihantar.");
    for(int i=0;i<names.length;i+=3){ LinearLayout row=new LinearLayout(this); row.setOrientation(0); root.addView(row);
      for(int j=i;j<Math.min(i+3,names.length);j++){final int idx=j;Button btn=button(names[j]);row.addView(btn,new LinearLayout.LayoutParams(0,110,1));btn.setOnClickListener(v->sendSaved(idx));}
    }
    title("IR CODE TESTER");label("Pilih butang, masukkan alamat dan arahan NEC dalam heksadesimal (00–FF). Uji satu kod pada satu masa. Kod NEC 8-bit standard sahaja.");
    Spinner selector=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);selector.setAdapter(adapter);root.addView(selector);
    selector.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){selected=pos;int a=prefs.getInt("a"+pos,0);int c=prefs.getInt("c"+pos,0);if(addressInput!=null){addressInput.setText(hex(a));commandInput.setText(hex(c));}}});
    addressInput=field("Alamat NEC (hex)","00");commandInput=field("Arahan NEC (hex)","00");
    Button test=button("UJI KOD IR");root.addView(test);test.setOnClickListener(v->test());
    Button save=button("SIMPAN UNTUK BUTANG INI");root.addView(save);save.setOnClickListener(v->{try{readCodes();prefs.edit().putInt("a"+selected,address).putInt("c"+selected,command).putBoolean("saved"+selected,true).apply();status.setText(names[selected]+" disimpan: "+hex(address)+" / "+hex(command));}catch(Exception e){status.setText("Kod mesti 00 hingga FF");}});
    Button next=button("KOD ARAHAN SETERUSNYA (+1)");root.addView(next);next.setOnClickListener(v->{try{int c=Integer.parseInt(commandInput.getText().toString().trim(),16);commandInput.setText(hex((c+1)&255));}catch(Exception e){commandInput.setText("00");}});
    label("Cara ujian: halakan IR telefon ke soundbar. Pilih POWER atau MUTE. Uji satu kod, perhatikan respons, kemudian cuba arahan seterusnya. Jangan jalankan ujian tanpa pengawasan. Sesetengah peranti menggunakan protokol selain NEC dan tidak akan memberi respons.");
  }
  void title(String s){TextView t=label(s);t.setTextSize(22);t.setTextColor(Color.WHITE);t.setPadding(0,18,0,10);}
  TextView label(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(0xffb8cadb);t.setTextSize(15);t.setPadding(6,8,6,12);root.addView(t);return t;}
  Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);return b;}
  EditText field(String hint,String initial){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setText(initial);e.setTextColor(Color.WHITE);e.setHintTextColor(0xffaab4c4);e.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);root.addView(e);return e;}
  String hex(int n){return String.format(java.util.Locale.US,"%02X",n);}
  void readCodes(){address=Integer.parseInt(addressInput.getText().toString().trim(),16);command=Integer.parseInt(commandInput.getText().toString().trim(),16);if(address<0||address>255||command<0||command>255)throw new IllegalArgumentException();}
  void test(){try{readCodes();send(address,command);status.setText("Ujian dihantar: "+hex(address)+" / "+hex(command)+" — semak soundbar");}catch(Exception e){status.setText("Gagal: semak kod 00–FF dan pemancar IR");}}
  void sendSaved(int idx){if(!prefs.getBoolean("saved"+idx,false)){status.setText("Belum ada kod untuk "+names[idx]+". Uji dan simpan dahulu.");return;}try{send(prefs.getInt("a"+idx,0),prefs.getInt("c"+idx,0));status.setText("Dihantar: "+names[idx]);}catch(Exception e){status.setText("IR gagal dihantar: "+e.getMessage());}}
  void send(int addr,int cmd){if(ir==null||!ir.hasIrEmitter())throw new IllegalStateException("Tiada IR blaster");
    // NEC standard 32-bit: address, inverted address, command, inverted command, LSB-first.
    int[] bytes={addr,addr^255,cmd,cmd^255};java.util.ArrayList<Integer> pulses=new java.util.ArrayList<>();pulses.add(9000);pulses.add(4500);
    for(int value:bytes){for(int bit=0;bit<8;bit++){pulses.add(560);pulses.add(((value>>bit)&1)==1?1690:560);}}
    pulses.add(560);int[] pattern=new int[pulses.size()];for(int i=0;i<pattern.length;i++)pattern[i]=pulses.get(i);
    ir.transmit(38000,pattern);
  }
}
