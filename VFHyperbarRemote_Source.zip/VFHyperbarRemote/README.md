# VF Hyperbar 300 BTU Remote — Android source

Android Studio project for Xiaomi 14 Ultra and other Android devices with Consumer IR transmitter.

## Build APK
1. Open this folder in Android Studio (with Android SDK 35 and JDK 17).
2. Allow Gradle sync (Android Gradle Plugin 8.7.3).
3. Build > Build APK(s).
4. Install the generated `app/build/outputs/apk/debug/app-debug.apk` on the phone.

## IR testing
- No verified IR codes are available for VF Hyperbar 300 BTU. **The remote buttons do not work until you test and save matching codes.**
- This tester emits only standard NEC 8-bit address + inverted address + 8-bit command + inverted command at 38 kHz.
- Select a button, enter address and command as 2-digit hexadecimal values, tap Test, and observe the soundbar. Use Next to increment command. Save only when confirmed.
- Try a known address from documentation first if available. Arbitrary code testing is not guaranteed to find a match: the soundbar may use a different protocol, carrier frequency, or extended address.
- The app does not receive/learn IR signals and does not scan automatically. The IR transmitter cannot read the original remote.
- This is an unofficial experimental application, not affiliated with VF.
